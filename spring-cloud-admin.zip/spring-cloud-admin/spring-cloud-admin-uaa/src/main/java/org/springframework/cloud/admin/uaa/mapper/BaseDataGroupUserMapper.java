package org.springframework.cloud.admin.uaa.mapper;

import org.springframework.cloud.admin.uaa.model.BaseDataGroupUser;
import tk.mybatis.mapper.common.Mapper;

public interface BaseDataGroupUserMapper extends Mapper<BaseDataGroupUser> {
}