package org.springframework.cloud.admin.uaa.mapper;

import org.springframework.cloud.admin.uaa.model.BaseDataGroup;
import tk.mybatis.mapper.common.Mapper;

public interface BaseDataGroupMapper extends Mapper<BaseDataGroup> {
}