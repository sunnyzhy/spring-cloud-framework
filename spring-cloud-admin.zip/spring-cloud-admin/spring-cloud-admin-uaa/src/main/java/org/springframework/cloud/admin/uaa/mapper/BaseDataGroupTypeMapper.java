package org.springframework.cloud.admin.uaa.mapper;

import org.springframework.cloud.admin.uaa.model.BaseDataGroupType;
import tk.mybatis.mapper.common.Mapper;

public interface BaseDataGroupTypeMapper extends Mapper<BaseDataGroupType> {
}