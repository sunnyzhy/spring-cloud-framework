package org.springframework.cloud.admin.common.to;

import lombok.Data;

/**
 * @author zhy
 * @date 2021/6/23 16:16
 */
@Data
public class LoginTo {
    private String userName;
}
