package org.springframework.cloud.admin.gateway.vo;

import lombok.Data;

/**
 * @author zhy
 * @date 2021/6/25 18:12
 */
@Data
public class AuthVo {
    private String userName;
    private String password;
}
